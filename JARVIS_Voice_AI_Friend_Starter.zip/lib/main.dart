import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

void main() {
  runApp(const JarvisApp());
}

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'JARVIS',
      theme: ThemeData.dark(useMaterial3: true),
      home: const JarvisHome(),
    );
  }
}

class JarvisHome extends StatefulWidget {
  const JarvisHome({super.key});

  @override
  State<JarvisHome> createState() => _JarvisHomeState();
}

class _JarvisHomeState extends State<JarvisHome> {
  bool listening = false;
  String status = 'Tap the microphone and talk to JARVIS';

  Future<void> startListening() async {
    final permission = await Permission.microphone.request();

    if (!permission.isGranted) {
      setState(() => status = 'Microphone permission is required.');
      return;
    }

    setState(() {
      listening = true;
      status = 'JARVIS is listening...';
    });

    // Speech-to-text and AI connection will be added in the next version.
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;
    setState(() {
      listening = false;
      status = 'Voice AI connection coming next.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF05070A),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'JARVIS',
                  style: TextStyle(
                    fontSize: 42,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 6,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Personal Voice AI Friend',
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 70),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: listening ? 190 : 160,
                  height: listening ? 190 : 160,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(width: 3),
                  ),
                  child: Icon(
                    listening ? Icons.graphic_eq : Icons.mic_none,
                    size: 72,
                  ),
                ),
                const SizedBox(height: 36),
                Text(
                  status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 28),
                FilledButton.icon(
                  onPressed: startListening,
                  icon: Icon(listening ? Icons.hearing : Icons.mic),
                  label: Text(listening ? 'Listening...' : 'Talk to JARVIS'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
