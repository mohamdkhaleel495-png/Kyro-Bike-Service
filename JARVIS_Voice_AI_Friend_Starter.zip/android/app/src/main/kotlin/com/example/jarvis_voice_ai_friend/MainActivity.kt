package com.example.jarvis_voice_ai_friend

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
