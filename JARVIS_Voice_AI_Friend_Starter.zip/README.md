# JARVIS – Personal Voice AI Friend

Starter Android/Flutter project structure for a voice-first personal AI friend.

## Current starter
- JARVIS branding
- Voice-first home screen
- Microphone permission request
- Tap-to-talk interface
- Placeholder voice response flow

## Next
Connect speech-to-text, an AI backend, text-to-speech, memory, and optional wake-word support.
