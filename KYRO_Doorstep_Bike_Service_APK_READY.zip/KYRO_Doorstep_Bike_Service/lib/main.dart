import 'package:flutter/material.dart';

void main() => runApp(const KyroApp());

class KyroApp extends StatelessWidget {
  const KyroApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KYRO Doorstep Bike Service',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff0878f9)),
        scaffoldBackgroundColor: const Color(0xfff4f8fc),
      ),
      home: const SplashScreen(),
    );
  }
}

const navy = Color(0xff061f3c);
const blue = Color(0xff0878f9);
const softBlue = Color(0xffeaf4ff);

class SplashScreen extends StatefulWidget { const SplashScreen({super.key});
  @override State<SplashScreen> createState()=>_SplashScreenState(); }
class _SplashScreenState extends State<SplashScreen> {
  @override void initState(){super.initState(); Future.delayed(const Duration(seconds:2),(){if(mounted) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const HomeScreen()));});}
  @override Widget build(BuildContext c)=>Scaffold(backgroundColor:navy,body:SafeArea(child:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    const Icon(Icons.two_wheeler,size:105,color:blue), const SizedBox(height:15),
    const Text('KYRO',style:TextStyle(color:Colors.white,fontSize:52,fontWeight:FontWeight.w900,letterSpacing:2)),
    const Text('Doorstep Bike Service',style:TextStyle(color:Colors.white,fontSize:18)), const SizedBox(height:40),
    const Text('Your Bike\nOur Care\nAt Your Doorstep',textAlign:TextAlign.center,style:TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.bold,height:1.35)),
    const SizedBox(height:55), const SizedBox(width:180,child:LinearProgressIndicator(minHeight:5))
  ]))));
}

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen>{ int tab=0;
  final services=[['General Service','Full checkup, cleaning, tuning','₹399',Icons.build],['Bike Repair','Electrical, wiring & minor repair','₹299',Icons.settings],['Engine Repair','Engine diagnosis & repair','₹1,499',Icons.precision_manufacturing],['Oil Change','Engine oil & filter change','₹49',Icons.opacity],['Brake Service','Brake check & replacement','₹59',Icons.album],['Emergency Breakdown','On-road / Home pickup service','₹199',Icons.warning_amber],['Water Wash','Complete bike cleaning','₹69',Icons.water_drop],['Wearing Problem','Clutch, chain, tyre, etc.','₹299',Icons.tire_repair]];
  @override Widget build(BuildContext c){ if(tab==1)return ServiceList(onBack:()=>setState(()=>tab=0)); if(tab==2)return const BookingsScreen(); if(tab==3)return const ProfileScreen(); return Scaffold(appBar:AppBar(backgroundColor:navy,foregroundColor:Colors.white,title:Row(children:[const Icon(Icons.two_wheeler),const SizedBox(width:7),const Text('KYRO',style:TextStyle(fontWeight:FontWeight.w900)),],),actions:[IconButton(onPressed:(){},icon:const Icon(Icons.notifications_none))]),body:ListView(padding:const EdgeInsets.all(14),children:[
    Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:navy,borderRadius:BorderRadius.circular(18)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Row(children:[Icon(Icons.location_on,color:Colors.white),SizedBox(width:5),Text('Shadnagar road pargi',style:TextStyle(color:Colors.white))]),const SizedBox(height:12),const Text('Bike Service\nat Your Doorstep',style:TextStyle(color:Colors.white,fontSize:28,fontWeight:FontWeight.w900)),const SizedBox(height:7),const Text('Fast | Reliable | Professional',style:TextStyle(color:Colors.white70)),const SizedBox(height:18),ElevatedButton(onPressed:()=>setState(()=>tab=1),child:const Text('Book Service Now'))]),
    const SizedBox(height:16),const Text('Our Services',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),itemCount:services.length,gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:1.35,crossAxisSpacing:10,mainAxisSpacing:10),itemBuilder:(c,i)=>ServiceCard(data:services[i],onTap:()=>setState(()=>tab=1))),
    const SizedBox(height:20),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Why KYRO?',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),SizedBox(height:10),Text('✓ Professional mechanics\n✓ Transparent pricing\n✓ Doorstep service\n✓ Easy booking & tracking',style:TextStyle(height:1.7))]) )
  ]),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.build_outlined),selectedIcon:Icon(Icons.build),label:'Services'),NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'Bookings'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile')]),); }
}

class ServiceCard extends StatelessWidget{final List data; final VoidCallback onTap; const ServiceCard({super.key,required this.data,required this.onTap}); @override Widget build(BuildContext c)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(15),child:Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(15),border:Border.all(color:const Color(0xffe0e9f2))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(width:38,height:38,decoration:BoxDecoration(color:softBlue,borderRadius:BorderRadius.circular(10)),child:Icon(data[3],color:blue)),const SizedBox(height:7),Text(data[0],style:const TextStyle(fontWeight:FontWeight.bold)),const Spacer(),Text(data[2],style:const TextStyle(color:blue,fontWeight:FontWeight.bold))])));}

class ServiceList extends StatelessWidget{final VoidCallback onBack; const ServiceList({super.key,required this.onBack}); final items=const [['General Service','Full checkup, cleaning, tuning','₹399',Icons.build],['Bike Repair','Electrical, wiring & minor repair','₹299',Icons.settings],['Engine Repair','Engine diagnosis & repair','₹1,499',Icons.precision_manufacturing],['Oil Only Change','Engine oil & filter change','₹49',Icons.opacity],['Brake Service','Brake check & replacement','₹59',Icons.album],['Emergency Breakdown','On-road / Home pickup service','₹199',Icons.warning_amber],['Water Wash','Complete bike cleaning','₹69',Icons.water_drop],['Wearing Problem','Clutch, chain, tyre, etc.','₹299',Icons.tire_repair]];
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Select Service'),leading:IconButton(onPressed:onBack,icon:const Icon(Icons.arrow_back))),body:ListView(padding:const EdgeInsets.all(14),children:items.map((x)=>Card(child:ListTile(contentPadding:const EdgeInsets.all(10),leading:CircleAvatar(backgroundColor:softBlue,child:Icon(x[3],color:blue)),title:Text(x[0],style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text(x[1]),trailing:Text(x[2],style:const TextStyle(color:blue,fontWeight:FontWeight.bold)),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>BookingFlow(service:x[0].toString(),price:x[2].toString()))))).toList()));
}

class BookingFlow extends StatefulWidget{final String service,price;const BookingFlow({super.key,required this.service,required this.price});@override State<BookingFlow> createState()=>_BookingFlowState();}
class _BookingFlowState extends State<BookingFlow>{int step=0;final name=TextEditingController();final phone=TextEditingController();final bike=TextEditingController();final address=TextEditingController();
 @override Widget build(BuildContext c){final titles=['Service Details','Bike Details','Address & Location','Date & Time','Booking Confirmed'];return Scaffold(appBar:AppBar(title:Text(titles[step]),leading:step==0?null:IconButton(onPressed:()=>setState(()=>step--),icon:const Icon(Icons.arrow_back))),body:Padding(padding:const EdgeInsets.all(18),child:step<4?ListView(children:[
  if(step==0)...[Icon(Icons.build_circle,size:90,color:blue),const SizedBox(height:15),Text(widget.service,style:const TextStyle(fontSize:25,fontWeight:FontWeight.bold)),const SizedBox(height:8),Text('Service charge: ${widget.price}',style:const TextStyle(fontSize:18,color:blue)),const SizedBox(height:25),const Text('Choose service option and continue.')],
  if(step==1)...[field('Customer Name',name),field('Mobile Number',phone,keyboard:TextInputType.phone),field('Bike Company & Model',bike),field('Vehicle Number',TextEditingController())],
  if(step==2)...[field('Enter your address',address,max:4),Container(height:180,margin:const EdgeInsets.only(top:10),decoration:BoxDecoration(color:softBlue,borderRadius:BorderRadius.circular(16)),child:const Center(child:Icon(Icons.location_on,size:65,color:blue))),const SizedBox(height:10),const Text('Location permission can be enabled for faster service.')],
  if(step==3)...[const Text('Select Date',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:['Today','Tomorrow','Next Day'].map((d)=>ChoiceChip(label:Text(d),selected:d=='Today',onSelected:(_){},)).toList()),const SizedBox(height:25),const Text('Select Time',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:['09:00 AM','10:00 AM','11:00 AM','12:00 PM','01:00 PM','02:00 PM','03:00 PM','04:00 PM'].map((t)=>ActionChip(label:Text(t),onPressed:(){})).toList())],
  const SizedBox(height:30),SizedBox(height:52,child:ElevatedButton(onPressed:(){setState(()=>step++);},child:Text(step==3?'Book Now':'Next')))
 ]):Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[const Icon(Icons.check_circle,size:100,color:Colors.green),const SizedBox(height:15),const Text('Booking Confirmed!',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),const SizedBox(height:10),Text('Your ${widget.service} request has been received.'),const SizedBox(height:25),ElevatedButton(onPressed:()=>Navigator.popUntil(c,(r)=>r.isFirst),child:const Text('Back to Home'))])));}
 Widget field(String label,TextEditingController controller,{TextInputType? keyboard,int max=1})=>Padding(padding:const EdgeInsets.only(bottom:14),child:TextField(controller:controller,keyboardType:keyboard,maxLines:max,decoration:InputDecoration(labelText:label,border:OutlineInputBorder(borderRadius:BorderRadius.circular(12)))));}

class BookingsScreen extends StatelessWidget{const BookingsScreen({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('My Bookings')),body:ListView(padding:const EdgeInsets.all(15),children:[Card(child:ListTile(leading:const CircleAvatar(child:Icon(Icons.build)),title:const Text('General Service'),subtitle:const Text('Hero Splendor Plus\nToday, 09:00 AM'),trailing:const Text('₹399',style:TextStyle(color:blue,fontWeight:FontWeight.bold))))]));}
class ProfileScreen extends StatelessWidget{const ProfileScreen({super.key});@override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Profile')),body:ListView(padding:const EdgeInsets.all(15),children:[const CircleAvatar(radius:45,child:Icon(Icons.person,size:55)),const SizedBox(height:12),const Center(child:Text('KYRO Customer',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),const SizedBox(height:20),...['My Bikes','Saved Addresses','Payment Methods','Notifications','Help & Support','About KYRO'].map((x)=>Card(child:ListTile(title:Text(x),trailing:const Icon(Icons.chevron_right))))]));}
