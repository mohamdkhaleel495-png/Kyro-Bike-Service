# KYRO Doorstep Bike Service

Customer Flutter app for doorstep bike servicing.

## Screens / flow
- Splash screen
- Home and services
- Service selection
- Bike details
- Address & location
- Date & time
- Booking confirmation
- My Bookings
- Profile

## Build APK on GitHub
The included GitHub Actions workflow creates the Android platform files, gets dependencies, builds a release APK, and uploads it as an artifact.

Workflow file: `.github/workflows/build-apk.yml`
