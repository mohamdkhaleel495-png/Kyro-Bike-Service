# KYRO Doorstep Bike Service App

This is a Flutter starter project based on the 15-screen KYRO app reference:
Splash, Home, Service Selection, Oil Selection, Bike Details, Address & Location,
Date & Time, Booking Confirmation, Track Mechanic, Bill & Payment, Rating,
My Bookings, Service Details, Location Permission and Profile.

## Run
1. Install Flutter 3.x and Android Studio.
2. Extract this folder.
3. Run:
   flutter pub get
   flutter run

## Build APK
flutter build apk --release

## Important
This version is a functional UI prototype. Real OTP, GPS, maps, payment gateway,
push notifications, mechanic/admin backend and live tracking need a backend/API
integration before production release.
