package com.kyro.doorstep_bike_service

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
