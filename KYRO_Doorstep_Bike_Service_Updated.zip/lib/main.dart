import 'package:flutter/material.dart';

void main() => runApp(const KyroApp());

const kyroBlue = Color(0xFF0878F9);
const darkBlue = Color(0xFF062743);
const bg = Color(0xFFF4F8FC);

class ServiceItem {
  final String name;
  final String subtitle;
  final int price;
  final IconData icon;
  const ServiceItem(this.name, this.subtitle, this.price, this.icon);
}

const services = [
  ServiceItem('General Service', 'Full checkup, cleaning, tuning & performance check', 399, Icons.build_rounded),
  ServiceItem('Bike Repair', 'Electrical, wiring, minor & major repair', 299, Icons.settings_rounded),
  ServiceItem('Engine Repair', 'Engine problem diagnosis & repair', 1499, Icons.engineering_rounded),
  ServiceItem('Oil Only Change', 'Engine oil & filter change', 49, Icons.water_drop_rounded),
  ServiceItem('Brake Service', 'Brake check & replacement', 59, Icons.album_rounded),
  ServiceItem('Emergency Breakdown', 'On-road / Home pickup service', 199, Icons.warning_amber_rounded),
  ServiceItem('Water Wash', 'Complete bike cleaning', 69, Icons.local_car_wash_rounded),
  ServiceItem('Wearing Problem', 'Clutch, chain, tyre, etc.', 299, Icons.settings_suggest_rounded),
];

class Booking {
  String service = 'General Service';
  int servicePrice = 399;
  String bike = 'Hero Splendor Plus';
  String vehicleNo = 'TS 07 AB 1234';
  String oil = 'Castrol';
  int oilPrice = 500;
  String address = 'Shadnagar road pargi';
  String date = 'Today, 14 Sep';
  String time = '09:00 AM';
  String payment = 'UPI';
  int get total => servicePrice + oilPrice;
}

class KyroApp extends StatefulWidget {
  const KyroApp({super.key});
  @override
  State<KyroApp> createState() => _KyroAppState();
}

class _KyroAppState extends State<KyroApp> {
  final booking = Booking();
  int tab = 0;

  void open(Widget page) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'KYRO Doorstep Bike Service',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: kyroBlue),
        fontFamily: 'Arial',
      ),
      home: HomeScreen(booking: booking, onOpen: open),
    );
  }
}

class AppBarTitle extends StatelessWidget {
  final String title;
  const AppBarTitle(this.title, {super.key});
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontWeight: FontWeight.w800));
}

class PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const PrimaryButton({super.key, required this.text, required this.onTap});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity,
    height: 52,
    child: FilledButton(
      onPressed: onTap,
      style: FilledButton.styleFrom(
        backgroundColor: kyroBlue,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
    ),
  );
}

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: darkBlue,
    body: SafeArea(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.two_wheeler_rounded, size: 90, color: kyroBlue),
            const SizedBox(height: 8),
            const Text('KYRO', style: TextStyle(color: Colors.white, fontSize: 58, fontWeight: FontWeight.w900, letterSpacing: 3)),
            const Text('Doorstep Bike Service', style: TextStyle(color: Colors.white70, fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 34),
            const Text('Your Bike\\nOur Care\\nAt Your Doorstep', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800, height: 1.25)),
            const SizedBox(height: 50),
            SizedBox(width: 180, child: LinearProgressIndicator(minHeight: 5, borderRadius: BorderRadius.circular(5))),
          ],
        ),
      ),
    ),
  );
}

class HomeScreen extends StatelessWidget {
  final Booking booking;
  final void Function(Widget) onOpen;
  const HomeScreen({super.key, required this.booking, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [Icon(Icons.two_wheeler_rounded, color: kyroBlue), SizedBox(width: 7), Text('KYRO', style: TextStyle(fontWeight: FontWeight.w900))]),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded))],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 100),
        children: [
          _locationCard(),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: darkBlue, borderRadius: BorderRadius.circular(18)),
            child: Row(children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
                Text('Bike Service\\nat Your Doorstep', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
                SizedBox(height: 5),
                Text('Fast • Reliable • Professional', style: TextStyle(color: Colors.white70)),
              ])),
              const Icon(Icons.two_wheeler_rounded, color: kyroBlue, size: 65),
            ]),
          ),
          const SizedBox(height: 18),
          const Text('Our Services', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: services.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, crossAxisSpacing: 8, mainAxisSpacing: 8, childAspectRatio: .9),
            itemBuilder: (_, i) => InkWell(
              onTap: () { booking.service = services[i].name; booking.servicePrice = services[i].price; onOpen(ServiceSelection(booking: booking)); },
              borderRadius: BorderRadius.circular(14),
              child: Container(
                padding: const EdgeInsets.all(7),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.blueGrey.shade50)),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  CircleAvatar(backgroundColor: kyroBlue.withOpacity(.1), child: Icon(services[i].icon, color: kyroBlue)),
                  const SizedBox(height: 6),
                  Text(services[i].name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
                  Text('₹${services[i].price}', style: const TextStyle(color: kyroBlue, fontWeight: FontWeight.w900)),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Why KYRO?', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          Row(children: const [
            Expanded(child: _Feature(Icons.speed_rounded, 'Fast Service')),
            Expanded(child: _Feature(Icons.verified_user_outlined, 'Trusted Mechanics')),
            Expanded(child: _Feature(Icons.receipt_long_rounded, 'Transparent Pricing')),
          ]),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: 0,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.build_outlined), selectedIcon: Icon(Icons.build), label: 'Services'),
          NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'Bookings'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _locationCard() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
    child: Row(children: [
      const Icon(Icons.location_on_rounded, color: kyroBlue),
      const SizedBox(width: 7),
      const Expanded(child: Text('Shadnagar road pargi', style: TextStyle(fontWeight: FontWeight.w700))),
      const Icon(Icons.keyboard_arrow_down_rounded),
    ]),
  );
}

class _Feature extends StatelessWidget {
  final IconData icon; final String text;
  const _Feature(this.icon, this.text);
  @override
  Widget build(BuildContext context) => Column(children: [Icon(icon, color: kyroBlue), const SizedBox(height: 4), Text(text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700))]);
}

class ServiceSelection extends StatelessWidget {
  final Booking booking;
  const ServiceSelection({super.key, required this.booking});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const AppBarTitle('Select Service')),
    body: ListView(
      padding: const EdgeInsets.all(14),
      children: [
        for (final s in services) Card(
          child: ListTile(
            leading: CircleAvatar(backgroundColor: kyroBlue, child: Icon(s.icon, color: Colors.white)),
            title: Text(s.name, style: const TextStyle(fontWeight: FontWeight.w800)),
            subtitle: Text(s.subtitle),
            trailing: Text('₹${s.price}', style: const TextStyle(fontWeight: FontWeight.w900, color: kyroBlue)),
            onTap: () { booking.service = s.name; booking.servicePrice = s.price; Navigator.push(context, MaterialPageRoute(builder: (_) => OilSelection(booking: booking))); },
          ),
        ),
      ],
    ),
  );
}

class OilSelection extends StatefulWidget {
  final Booking booking;
  const OilSelection({super.key, required this.booking});
  @override State<OilSelection> createState() => _OilSelectionState();
}
class _OilSelectionState extends State<OilSelection> {
  String oil = 'Castrol';
  final oils = {'Castrol':500, 'Motul':450, 'HP':400, 'Other':0};
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const AppBarTitle('Service & Engine Oil')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Container(height: 155, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Center(child: Icon(Icons.two_wheeler_rounded, size: 100, color: kyroBlue))),
      const SizedBox(height: 12),
      Text(widget.booking.service, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
      Text('Select your engine oil and see the total bill before confirming.', style: TextStyle(color: Colors.grey.shade700)),
      const SizedBox(height: 16),
      const Text('Choose Engine Oil', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      for (final e in oils.entries) RadioListTile<String>(
        value: e.key, groupValue: oil, activeColor: kyroBlue, onChanged: (v) => setState(() => oil = v!),
        title: Text(e.key), subtitle: Text('₹${e.value}'), dense: true,
      ),
      const Divider(),
      _row('Service Charge', '₹${widget.booking.servicePrice}'),
      _row('Oil Price', '₹${oils[oil]}'),
      _row('Total Amount', '₹${widget.booking.servicePrice + oils[oil]!}', bold: true),
      const SizedBox(height: 16),
      PrimaryButton(text: 'Confirm Service Booking', onTap: () { widget.booking.oil = oil; widget.booking.oilPrice = oils[oil]!; Navigator.push(context, MaterialPageRoute(builder: (_) => BikeDetails(booking: widget.booking))); }),
    ]),
  );
}

Widget _row(String a, String b, {bool bold=false}) => Padding(padding: const EdgeInsets.symmetric(vertical: 7), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(a, style: TextStyle(fontWeight: bold ? FontWeight.w900 : FontWeight.w600)), Text(b, style: TextStyle(fontWeight: FontWeight.w900, color: bold ? darkBlue : Colors.black))]));

class BikeDetails extends StatefulWidget {
  final Booking booking;
  const BikeDetails({super.key, required this.booking});
  @override State<BikeDetails> createState() => _BikeDetailsState();
}
class _BikeDetailsState extends State<BikeDetails> {
  final number = TextEditingController(text: 'TS 07 AB 1234');
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const AppBarTitle('Bike Details')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      _drop('Bike Company & Model', 'Hero', 'Splendor Plus'),
      const SizedBox(height: 12),
      const Text('Vehicle Number', style: TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 6),
      TextField(controller: number, decoration: _dec(Icons.confirmation_number_outlined)),
      const SizedBox(height: 16),
      const Text('Select Bike Type', style: TextStyle(fontWeight: FontWeight.w800)),
      const SizedBox(height: 8),
      Row(children: const [_BikeType(Icons.two_wheeler, 'Bike'), _BikeType(Icons.electric_scooter, 'Scooty'), _BikeType(Icons.motorcycle, 'Sports')]),
      const SizedBox(height: 20),
      Container(height: 210, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Center(child: Icon(Icons.two_wheeler_rounded, size: 145, color: kyroBlue))),
      const SizedBox(height: 16),
      PrimaryButton(text: 'Next', onTap: () { widget.booking.vehicleNo = number.text; Navigator.push(context, MaterialPageRoute(builder: (_) => AddressLocation(booking: widget.booking))); }),
    ]),
  );
}
Widget _drop(String label, String a, String b) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(label, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 6), Row(children: [Expanded(child: DropdownButtonFormField<String>(value: a, items: [DropdownMenuItem(value:a, child:Text(a))], onChanged:(_){}, decoration:_dec(null))), const SizedBox(width:8), Expanded(child: DropdownButtonFormField<String>(value:b, items:[DropdownMenuItem(value:b, child:Text(b))], onChanged:(_){}, decoration:_dec(null)))])]);
InputDecoration _dec(IconData? icon) => InputDecoration(prefixIcon: icon == null ? null : Icon(icon), filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none));

class _BikeType extends StatelessWidget {
  final IconData icon; final String name;
  const _BikeType(this.icon, this.name);
  @override Widget build(BuildContext context) => Expanded(child: Container(margin: const EdgeInsets.only(right:7), padding: const EdgeInsets.symmetric(vertical:12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: name=='Bike'?kyroBlue:Colors.transparent, width: 2)), child: Column(children:[Icon(icon,color:kyroBlue), const SizedBox(height:4), Text(name, style:const TextStyle(fontWeight:FontWeight.w700))])));
}

class AddressLocation extends StatefulWidget {
  final Booking booking;
  const AddressLocation({super.key, required this.booking});
  @override State<AddressLocation> createState() => _AddressLocationState();
}
class _AddressLocationState extends State<AddressLocation> {
  final address = TextEditingController(text: 'Shadnagar road pargi');
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const AppBarTitle('Address & Location')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: FilledButton(onPressed:(){}, child:const Text('Enter Address'))), Expanded(child: TextButton(onPressed:(){}, child:const Text('Use My Location')))]),
      const SizedBox(height: 8),
      TextField(controller: address, maxLines: 2, decoration: _dec(Icons.location_on_outlined)),
      const SizedBox(height: 10),
      Container(height: 260, decoration: BoxDecoration(color: const Color(0xFFE5EEF6), borderRadius: BorderRadius.circular(14)), child: const Center(child: Icon(Icons.location_on, size: 58, color: kyroBlue))),
      const SizedBox(height: 12),
      Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)), child: Row(children:[const Icon(Icons.location_on, color:kyroBlue), const SizedBox(width:8), Expanded(child:Text('Your Location\\nShadnagar road pargi',style:TextStyle(fontWeight:FontWeight.w700))), TextButton(onPressed:(){},child:const Text('Change'))])),
      const SizedBox(height: 12),
      PrimaryButton(text:'Next', onTap:(){ widget.booking.address=address.text; Navigator.push(context,MaterialPageRoute(builder:(_)=>DateTimeBooking(booking:widget.booking))); }),
    ]),
  );
}

class DateTimeBooking extends StatefulWidget {
  final Booking booking;
  const DateTimeBooking({super.key, required this.booking});
  @override State<DateTimeBooking> createState()=>_DateTimeBookingState();
}
class _DateTimeBookingState extends State<DateTimeBooking>{
  String date='Today, 14 Sep', time='09:00 AM';
  final times=['09:00 AM','10:00 AM','11:00 AM','12:00 PM','01:00 PM','02:00 PM','03:00 PM','04:00 PM','05:00 PM'];
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const AppBarTitle('Date & Time')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      const Text('Select Date',style:TextStyle(fontWeight:FontWeight.w800)),
      const SizedBox(height:8),
      Row(children:[for(final d in ['Today, 14 Sep','Mon, 15 Sep','Tue, 16 Sep','Wed, 17 Sep']) Expanded(child:GestureDetector(onTap:()=>setState(()=>date=d),child:Container(margin:const EdgeInsets.only(right:5),padding:const EdgeInsets.symmetric(vertical:12),decoration:BoxDecoration(color:d==date?kyroBlue:Colors.white,borderRadius:BorderRadius.circular(10)),child:Text(d.split(',').first,textAlign:TextAlign.center,style:TextStyle(color:d==date?Colors.white:Colors.black,fontWeight:FontWeight.w700)))))]),
      const SizedBox(height:16), const Text('Select Time',style:TextStyle(fontWeight:FontWeight.w800)), const SizedBox(height:8),
      GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:3,mainAxisSpacing:8,crossAxisSpacing:8,childAspectRatio:2.4,children:[for(final t in times)GestureDetector(onTap:()=>setState(()=>time=t),child:Container(alignment:Alignment.center,decoration:BoxDecoration(color:t==time?kyroBlue:Colors.white,borderRadius:BorderRadius.circular(9)),child:Text(t,style:TextStyle(color:t==time?Colors.white:Colors.black,fontWeight:FontWeight.w700))))]),
      const SizedBox(height:16), const Text('Special Note (Optional)',style:TextStyle(fontWeight:FontWeight.w800)), const SizedBox(height:7), TextField(maxLines:3,decoration:_dec(null).copyWith(hintText:'Any special request...')),
      const SizedBox(height:18), PrimaryButton(text:'Book Now',onTap:(){widget.booking.date=date;widget.booking.time=time;Navigator.push(context,MaterialPageRoute(builder:(_)=>Confirmation(booking:widget.booking)));})
    ])
  );
}

class Confirmation extends StatelessWidget {
  final Booking booking;
  const Confirmation({super.key,required this.booking});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const AppBarTitle('Booking Confirmation')),
    body:Center(child:Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
      const CircleAvatar(radius:42,backgroundColor:Color(0xFFE1F7EB),child:Icon(Icons.check_rounded,size:55,color:Colors.green)),
      const SizedBox(height:16),const Text('Booking Confirmed!',style:TextStyle(fontSize:27,fontWeight:FontWeight.w900)),const SizedBox(height:8),
      Text('Your service request has been received.\\nWe will assign a mechanic shortly.',textAlign:TextAlign.center,style:TextStyle(color:Colors.grey.shade700)),
      const SizedBox(height:20),_row('Booking ID','#KYRO12546'),_row('Service',booking.service),_row('Bike',booking.bike),_row('Date & Time','${booking.date}, ${booking.time}'),_row('Address',booking.address),
      const SizedBox(height:20),PrimaryButton(text:'Track Mechanic',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>TrackMechanic(booking:booking))))
    ]))
  );
}

class TrackMechanic extends StatelessWidget {
  final Booking booking;
  const TrackMechanic({super.key,required this.booking});
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const AppBarTitle('Track Mechanic')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Container(height:360,decoration:BoxDecoration(color:const Color(0xFFDCE9F2),borderRadius:BorderRadius.circular(16)),child:Stack(children:[const Center(child:Icon(Icons.map_rounded,size:190,color:Colors.white70)),Positioned(left:70,top:220,child:const Icon(Icons.two_wheeler,size:48,color:darkBlue)),Positioned(right:50,top:80,child:const CircleAvatar(radius:28,child:Icon(Icons.person))) ])),
      const SizedBox(height:12),ListTile(tileColor:Colors.white,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12)),leading:const CircleAvatar(child:Icon(Icons.person)),title:const Text('Raju Kumar',style:TextStyle(fontWeight:FontWeight.w900)),subtitle:const Text('Bike Mechanic • Arriving in 12 min'),trailing:IconButton(onPressed:(){},icon:const Icon(Icons.phone,color:kyroBlue))),
      const SizedBox(height:10),PrimaryButton(text:'View Service Bill',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>BillPayment(booking:booking))))
    ])
  );
}

class BillPayment extends StatefulWidget {
  final Booking booking;
  const BillPayment({super.key,required this.booking});
  @override State<BillPayment> createState()=>_BillPaymentState();
}
class _BillPaymentState extends State<BillPayment>{
  String payment='UPI';
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const AppBarTitle('Service Bill')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16)),child:Column(children:[
        _row(widget.booking.service,'₹${widget.booking.servicePrice}'),_row('${widget.booking.oil} Engine Oil (1L)','₹${widget.booking.oilPrice}'),_row('Oil Filter','₹150'),_row('Labor Charge','₹400'),const Divider(),_row('Total Amount','₹${widget.booking.total+550}',bold:true)
      ])),
      const SizedBox(height:16),const Text('Payment Method',style:TextStyle(fontWeight:FontWeight.w900)),
      for(final p in ['UPI (Google Pay / PhonePe / Paytm)','Card','Cash on Delivery']) RadioListTile<String>(value:p,groupValue:payment,onChanged:(v)=>setState(()=>payment=v!),title:Text(p),dense:true),
      PrimaryButton(text:'Pay ₹${widget.booking.total+550}',onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>RatingScreen())))
    ])
  );
}

class RatingScreen extends StatefulWidget {
  const RatingScreen({super.key});
  @override State<RatingScreen> createState()=>_RatingScreenState();
}
class _RatingScreenState extends State<RatingScreen>{
  int stars=5;
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const AppBarTitle('Rate Your Experience')),body:Padding(padding:const EdgeInsets.all(20),child:Column(children:[
    const SizedBox(height:35),const Text('Thank you for choosing KYRO!',style:TextStyle(fontSize:20,fontWeight:FontWeight.w900)),const SizedBox(height:18),
    Row(mainAxisAlignment:MainAxisAlignment.center,children:[for(int i=1;i<=5;i++)IconButton(onPressed:()=>setState(()=>stars=i),icon:Icon(Icons.star,size:38,color:i<=stars?Colors.amber:Colors.grey.shade300))]),
    TextField(maxLines:4,decoration:_dec(null).copyWith(hintText:'Write your review (optional)')),
    const Spacer(),PrimaryButton(text:'Submit',onTap:()=>Navigator.popUntil(context,(r)=>r.isFirst))
  ]));
}

class MyBookings extends StatelessWidget {
  const MyBookings({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const AppBarTitle('My Bookings')),body:ListView(padding:const EdgeInsets.all(16),children:[
    _bookingCard('#KYRO12546','General Service','14 Sep, 09:00 AM','On the Way','₹899'),
    _bookingCard('#KYRO11890','Bike Service','10 Sep, 11:00 AM','Completed','₹599'),
  ]);
}
Widget _bookingCard(String id,String service,String dt,String status,String price)=>Card(child:ListTile(title:Text(id,style:const TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('$service\\n$dt'),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[Text(status,style:const TextStyle(color:Colors.green,fontWeight:FontWeight.w800)),Text(price,style:const TextStyle(color:kyroBlue,fontWeight:FontWeight.w900))])));

class LocationPermission extends StatelessWidget {
  const LocationPermission({super.key});
  @override Widget build(BuildContext context)=>Scaffold(backgroundColor:darkBlue,body:Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    const CircleAvatar(radius:52,backgroundColor:Colors.white,child:Icon(Icons.location_on,size:62,color:kyroBlue)),const SizedBox(height:24),
    const Text('Allow Location Access',style:TextStyle(color:Colors.white,fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:10),
    const Text('We need your location to:\\n• Find the nearest mechanic\\n• Provide faster service\\n• Track your service in real-time',textAlign:TextAlign.center,style:TextStyle(color:Colors.white70,height:1.6)),
    const SizedBox(height:28),PrimaryButton(text:'Allow Location Access',onTap:()=>Navigator.pop(context)),const SizedBox(height:10),TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Maybe Later',style:TextStyle(color:Colors.white)))
  ])));
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const AppBarTitle('Profile')),body:ListView(padding:const EdgeInsets.all(16),children:[
    const ListTile(leading:CircleAvatar(radius:30,child:Icon(Icons.person)),title:Text('Mohammed Khaleel',style:TextStyle(fontWeight:FontWeight.w900)),subtitle:Text('+91 6281704781')),
    for(final x in ['My Bikes','Saved Addresses','Payment Methods','Notifications','Help & Support','About KYRO']) Card(child:ListTile(title:Text(x),trailing:const Icon(Icons.chevron_right)))
  ]));
}
